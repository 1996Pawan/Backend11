package costomerxps.demo.repository;

import costomerxps.demo.model.MessageCode;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.swing.*;
import java.util.List;
/*
   INTRACT with database to add the message and retrive the details of message from the messaegCode Table.
 */
public interface MessageCodeRepository extends JpaRepository<MessageCode,Integer>
{
  public List<MessageCode> findByType(String typeRequest);
 public List<MessageCode> findByCode(String codeRequest);
    public List<MessageCode> findByMessage(String messageRequest);




}
