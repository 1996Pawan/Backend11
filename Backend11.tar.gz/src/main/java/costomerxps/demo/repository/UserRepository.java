package costomerxps.demo.repository;

import costomerxps.demo.model.User;
import costomerxps.demo.model.MessageCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

/*
  Intract With user database to add user and validate user From user table.
 */
@org.springframework.stereotype.Repository
public interface UserRepository extends JpaRepository<User,Integer>
{
    public User findByEmailAndPassword(String email, String password);
}
