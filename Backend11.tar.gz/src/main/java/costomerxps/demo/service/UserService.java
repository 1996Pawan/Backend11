package costomerxps.demo.service;


import costomerxps.demo.vo.AddCode;
import costomerxps.demo.vo.AddUser;
import costomerxps.demo.vo.UserRequest;
import org.springframework.stereotype.Service;

/*
Interface for add the user and validate the user in the database table(user).
 */
public interface UserService
{
    public  boolean addUser(AddUser addUser);



    public boolean validateUser(UserRequest userRequest);

}
