package costomerxps.demo.service;

import costomerxps.demo.model.MessageCode;
import costomerxps.demo.model.User;
import costomerxps.demo.repository.UserRepository;
import costomerxps.demo.vo.AddCode;
import costomerxps.demo.vo.AddUser;
import costomerxps.demo.vo.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Base64;

//Logic To add the user.
@Service
public class UserServiceImp implements UserService
{

    @Autowired
    private UserRepository userRepository;
    /*
    Logic to add the user email and password in the database table(user)
     */
    @Override
    public boolean addUser(AddUser addUser)
    {
        String email=addUser.getEmail();
        String password=addUser.getPassword();
        String encodedString = Base64.getEncoder().encodeToString(password.getBytes());
       String name=addUser.getName();

        User user=new User();
        user.setEmail(email);
        user.setPassword(encodedString);
        user.setName(name);
        try
        {
            userRepository.save(user);

        }
        catch (Exception e)
        {
            System.out.println("!!Email already exist");
            return false ;

        }

        return true;
    }


/*
        Logic to validate the user request or Emailid and Password.
 */
    @Override
    public boolean validateUser(UserRequest userRequest)
    {
       Boolean userexist=false;
       String email=userRequest.getEmail();
       String password=userRequest.getPassword();
       System.out.println(password);
        String encodedString = Base64.getEncoder().encodeToString(password.getBytes());
       User user=userRepository.findByEmailAndPassword(email,encodedString);
       System.out.println(user);

       if(user==null)
       {
           userexist=false;
           System.out.println("!!invalid user emailid and password");
       }
       else
           userexist=true;
       return userexist;


    }
}
