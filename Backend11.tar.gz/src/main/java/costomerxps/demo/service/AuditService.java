package costomerxps.demo.service;

import costomerxps.demo.model.MessageCode;
import org.springframework.stereotype.Service;

import java.util.List;
/*
Interface For Audit Screen/ History Screen.
 */

@Service
public interface AuditService
{
    public List<MessageCode> getAudit();
}

