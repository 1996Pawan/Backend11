package costomerxps.demo.service;

import costomerxps.demo.model.MessageCode;
import costomerxps.demo.repository.MessageCodeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
/*
  Logic To get All data from messageCode Screen.
 */
@Service
public class AuditSerViceImp implements AuditService
{
    @Autowired
    MessageCodeRepository messageCodeRepository;

    @Override
    public List<MessageCode> getAudit()
    {
        return messageCodeRepository.findAll();


    }
}
