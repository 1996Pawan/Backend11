package costomerxps.demo.service;

import costomerxps.demo.model.MessageCode;
import costomerxps.demo.repository.MessageCodeRepository;
import costomerxps.demo.vo.AddCode;
//import costomerxps.demo.vo.MessageCodeRequest;
import javassist.bytecode.stackmap.BasicBlock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@Service
public class MessageCodeServiceImp implements MessageCodeService {
    @Autowired
    private MessageCodeRepository messageCodeRepository;


    /*
    Logic to add the  Messagecode in messageCode database table.
     */
    @Override
    public boolean addCode(AddCode addCode) {
        String type = addCode.getType();
        String message = addCode.getMessage();
        String code = addCode.getCode();
        String createdBy=addCode.getCreatedBy();

        MessageCode messageCode = new MessageCode();
        messageCode.setType(type);
        messageCode.setMessage(message);
        messageCode.setCode(code);
        messageCode.setCreatedTime(new Date());
        messageCode.setCreatedBy(createdBy);

     try {
         messageCodeRepository.save(messageCode);
        }
     catch (DataIntegrityViolationException e)
     {
         System.out.println("!! Code Already Exist");
         return false;
     }

     return true;
    }

    /*
     Logic for Return the Information Basis On Type from the Dtatbase.
     */

    public List<MessageCode> getType(String typeRequest)
    {
        List<MessageCode> messageType = messageCodeRepository.findByType(typeRequest);


        return messageType;

    }
/*
     logic for Return the Information Basis On Code from the Dtatbase.
 */
public List<MessageCode> getCode(String codeRequest)
{
   List<MessageCode> messageCode1 = messageCodeRepository.findByCode(codeRequest);
    return messageCode1;

}
    /*
     Logic for Return the Information Basis On Message from the Dtatbase.
     */
    public List<MessageCode> getMessage(String messageRequest)
    {
        List<MessageCode> messageCode2 = messageCodeRepository.findByMessage(messageRequest);

        return messageCode2;

    }

    @Override
    public boolean updateCode(AddCode addCode)
    {
        Boolean isUpdated =false;
        String type = addCode.getType();
        String message = addCode.getMessage();

        String createdBy=addCode.getCreatedBy();

       // MessageCode messageCode = new MessageCode();
        MessageCode messageCode =messageCodeRepository.findById(addCode.getId()).get();
        if(Optional.ofNullable(messageCode).isPresent()) {
            messageCode.setType(type);
            messageCode.setCode(addCode.getCode());
            messageCode.setMessage(message);

            try {
                messageCodeRepository.save(messageCode);
                isUpdated=true;
            } catch (DataIntegrityViolationException e) {
                System.out.println("!! Code Already Exist");
               return false;
            }
        }
        return isUpdated ;
    }

}
