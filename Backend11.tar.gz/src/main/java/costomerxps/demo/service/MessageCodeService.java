package costomerxps.demo.service;

import costomerxps.demo.model.MessageCode;
import costomerxps.demo.vo.AddCode;

import java.util.HashMap;
import java.util.List;
/*
    Interface to add message and view message
 */

public interface MessageCodeService
{
    public boolean addCode(AddCode addCode);
    public List<MessageCode> getType(String typeRequest);
    public List<MessageCode> getCode(String codeRequest);

    public List<MessageCode> getMessage(String messageRequest);

    public boolean updateCode(AddCode addCode);
}
