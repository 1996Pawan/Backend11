package costomerxps.demo.controller;

import costomerxps.demo.model.MessageCode;
import costomerxps.demo.service.MessageCodeService;
import costomerxps.demo.vo.AddCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@CrossOrigin(origins = "*",maxAge = 3600)
public class GetMessageController {

    @Autowired
    MessageCodeService messageCodeService;
/*
Get message information by giving input as Type.
 */
    @GetMapping("/getType")
    public List<MessageCode> getType(@RequestParam("typeRequest") String typeRequest)
    {
        List<MessageCode> messageType=messageCodeService.getType(typeRequest);
        return messageType;
    }
    /*
    Get message information by giving input as Code.
            */
    @GetMapping("/getCode")
    public List<MessageCode> getCode(@RequestParam("code") String codeRequest)
    {
       return messageCodeService.getCode(codeRequest);
   }
   /*
    Get message information by giving input as Message Name.
            */
    @GetMapping("/getMessage")
    public List<MessageCode> getMessage(@RequestParam("name") String messageRequest)
    {
        System.out.println("dsadas "+messageRequest);
        return messageCodeService.getMessage(messageRequest);

    }
}
