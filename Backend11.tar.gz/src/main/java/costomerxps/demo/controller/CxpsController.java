package costomerxps.demo.controller;

import costomerxps.demo.model.MessageCode;
import costomerxps.demo.service.MessageCodeService;
import costomerxps.demo.service.UserService;
import costomerxps.demo.vo.AddCode;
import costomerxps.demo.vo.AddUser;

import costomerxps.demo.vo.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.awt.*;
import java.util.HashMap;


@RestController
@CrossOrigin(origins = "*",maxAge = 3600,allowedHeaders = "*",allowCredentials = "true")
public class CxpsController
{
    @Autowired
    private UserService userService;

    @Autowired
    private MessageCodeService messageCodeService;
/*
     To ADD the Email and Password in the DataBase.
 */
    @PostMapping(path="/addUser",produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
    public HashMap<String,Boolean> addUser(@RequestBody AddUser addUser)
    {
        HashMap<String,Boolean> hm = new HashMap<String, Boolean>();
        Boolean addUser2=userService.addUser(addUser);
        System.out.println(" "+addUser2);
        hm.put("status",addUser2);
        return hm;
    }
    /*
    To VALIDATE the user email at the time of login.
     */
    @PostMapping(path="/validateUser",produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
    public HashMap<String, Object> validateUser(@RequestBody UserRequest userRequest)
    {
        HashMap<String,Object> hashMap = new HashMap<>();

        Boolean userExist = userService.validateUser(userRequest);
        if(userExist)
        {
            hashMap.put("emailId",userRequest.getEmail());
        }
        System.out.println((userExist));
        hashMap.put("status",userExist);

        return hashMap;

    }

    /*
    To ADD MESSAGE IN THE DATABASE "POST REQUEST"
     */
    @PostMapping(path = "/addCode",produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
    public HashMap<String, Boolean> addCode(@RequestBody AddCode addCode)
    {

        HashMap<String,Boolean> hs=new HashMap<>();
        hs.put("status",messageCodeService.addCode(addCode));

        return hs;
    }

    @PutMapping(path = "/updateCode",produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
    public HashMap<String, Boolean> updateCode(@RequestBody AddCode addCode)
    {

        HashMap<String,Boolean> hs=new HashMap<>();
        hs.put("status",messageCodeService.updateCode(addCode));

        return hs;
    }



}
