package costomerxps.demo.model;


import javax.persistence.*;
import java.util.Date;
/*
    MESSAGE CODE TABLE.
 */
@Entity
@Table(name = "messagecode")
public class MessageCode
{
    @GeneratedValue
    @Id
    @Column
    private int id;
    @Column
    private String type;
    @Column
    private String message;
    @Column(unique = true)
    private String code;
    @Column(name="created_time")
    private Date createdTime;

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Column
    private String createdBy;

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
